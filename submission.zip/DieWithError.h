#ifndef DIEWITHERROR_H
#define DIEWITHERROR_H

void DieWithError(const char *errorMessage);

#endif
 
